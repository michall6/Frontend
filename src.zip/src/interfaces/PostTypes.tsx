export interface PostType {
    title: string;
    url: string;
    selftext: string;
    sentiment: string;
  }
  