export default interface IHistory {
    id:string;
    subreddit:string;
    category:string;
    date_created:Date;
}