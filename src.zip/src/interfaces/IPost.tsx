export default interface IPost {
    title: string;
    id: string;
    sentiment: string;
    selftext:string;
    date_created:Date;
}